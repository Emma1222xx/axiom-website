AXIOM V1 — free static website

FILES:
- index.html
- axiom-logo.png

LOCAL TEST:
1. Put both files in the same folder.
2. Open index.html in a browser.

FREE DEPLOYMENT:
Upload both files to a GitHub repository and enable GitHub Pages from Settings > Pages.
No server or database is required for this V1.

WHATSAPP:
The site is configured for +234 913 032 9266.
